function sample(){
	var message: string = "Hello world"
	alert(message); 
}
let lst: number[] = [1, 2, 3, 4];
lst[0] = 2;