let outputElem = document.getElementById("output");

interface IDictionary<TValue> {
    [id: string]: TValue;
}

let userLanguages:IDictionary<string> = {
  "Mike": "en",
  "Teresa": "es"
};

function greetUser(user:string):void {
  function localGreeting(user:string):string {
    let greeting;
    let language = userLanguages[user];

    switch(language) {
      case "es":
        greeting = `¡Hola, ${user}!`;
        break;
      case "en":
      default:
        greeting = `Hello, ${user}!`;
        break;
    }
    return greeting;
  }
  if (outputElem)
    outputElem.innerHTML += localGreeting(user) + "<br>\r";
}

greetUser("Mike");
greetUser("Teresa");
greetUser("Veronica");
