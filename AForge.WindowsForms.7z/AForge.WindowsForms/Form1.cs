﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;

namespace CameraController
{
    public partial class Form1 : Form
    {
        private FilterInfoCollection videoDevicesList;
        private VideoCaptureDevice videoSource;
        private static List<Bitmap> ListToLoad=new List<Bitmap>();
        public Form1()
        {
            InitializeComponent();
            Application.DoEvents();
        }

        MJPEGStream stream;

        private void Stream_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {


            Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
            var oldImage = pictureBox1.Image;
            pictureBox1.Image = GetImageFromFolder(bitmap);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            oldImage?.Dispose();
        }


        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            stream?.SignalToStop();
            if (stream != null)
                stream.NewFrame -= Stream_NewFrame;
            // signal to stop
            if (videoSource != null && videoSource.IsRunning)
            {
                try
                {
                    videoSource.SignalToStop();
                    Application.DoEvents();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            InitializeClass.StartingForm.Hide();
            InitializeClass.StartingForm.Dispose();
            Application.DoEvents();
        }

        private void video_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            if (ImageLoader.IsDirExists())
            {
                Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
                var oldImage = pictureBox1.Image;
                pictureBox1.Image = GetImageFromFolder(bitmap);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                oldImage?.Dispose();
            }
            else
            {
                Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
                var oldImage = pictureBox1.Image;
                pictureBox1.Image = bitmap;
                oldImage?.Dispose();
            }
        }
        public static int index = 0;

        public string FolderImages { get; internal set; }

        public static Bitmap GetImageFromFolder(Bitmap original)
        {
            try
            {
                //create a blank bitmap the same size as original
                Bitmap newBitmap = new Bitmap(original.Width, original.Height);
                Bitmap from = ListToLoad[index];
                if (Form1.index == ListToLoad.Count - 1)
                    Form1.index = 0;
                else
                    Form1.index++;

                using (var canvas = Graphics.FromImage(newBitmap))
                {
                    canvas.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    canvas.DrawImage(original,
                                     new Rectangle(0,
                                                   0,
                                                   original.Width,
                                                   original.Height),
                                     new Rectangle(0,
                                                   0,
                                                   original.Width,
                                                   original.Height),
                                     GraphicsUnit.Pixel);
                    canvas.DrawImage(from,
                                     0, 0);
                    canvas.Save();
                }
                original.Dispose();
                return newBitmap;
            }
            catch (Exception e)
            {
                return original;
            }

        }
        bool fullScreen = false;
        Size lastSize;
        private void AltEnter()
        {
            try
            {
                if (!fullScreen)
                {
                    lastSize = this.Size;
                }
                else
                {
                    this.Size = lastSize;
                }
                HideBorder(fullScreen);
                fullScreen = !fullScreen;
            }
            catch
            {

            }
        }

        private void HideBorder(bool state)
        {
            var size = Size;
            int height = size.Height;
            int width = size.Width;
            this.WindowState = state ? FormWindowState.Normal : FormWindowState.Maximized;
            this.FormBorderStyle = state ? FormBorderStyle.Sizable : FormBorderStyle.None;
            // this.pictureBox1.Size = state && height < 150 ? new Size(width, height - 150) : size;
            this.btnStart.Visible = state;
            this.btnStop.Visible = state;
            this.cmbVideoSource.Visible = state;
            this.label1.Visible = state;
            Application.DoEvents();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.Enter))
            {
                AltEnter();
                return true;
            }
            // Call the base class
            return base.ProcessCmdKey(ref msg, keyData);
        }
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        void Form_Load(object sender, EventArgs e)
        {
            if (ImageLoader.IsDirExists())
            {
                ListToLoad.AddRange(ImageLoader.GetFromDir());
            }
            try
            {
                videoDevicesList = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                foreach (FilterInfo videoDevice in videoDevicesList)
                {
                    cmbVideoSource.Items.Add(videoDevice.Name);
                }
                if (cmbVideoSource.Items.Count > 0)
                {
                    cmbVideoSource.SelectedIndex = 0;
                }
                else
                {
                    MessageBox.Show("No video sources found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                // stop the camera on window close
                this.Closing += Form1_Closing;

                //    stream = new MJPEGStream(ImageLoader.ImaguRI);
                //    stream.NewFrame += Stream_NewFrame;
                //   stream.Start();


                this.MouseDown += new MouseEventHandler(Form_MouseDown);
                pictureBox1.MouseDown += new MouseEventHandler(Form_MouseDown);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            InitializeClass.StartingForm.Hide();
        }

        void Form_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (fullScreen)
                {
                    HideBorder(fullScreen);
                    fullScreen = !fullScreen;
                }
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void btnStart_Click_1(object sender, EventArgs e)
        {
            try
            {
                videoSource = new VideoCaptureDevice(videoDevicesList[cmbVideoSource.SelectedIndex].MonikerString);
                var assa = videoSource.VideoCapabilities;
                videoSource.VideoResolution = videoSource.VideoCapabilities[cmbCameraMode.SelectedIndex > -1 ? cmbCameraMode.SelectedIndex : 5];
                //pictureBox1.Width = videoSource.VideoResolution.FrameSize.Width;
                //pictureBox1.Height = videoSource.VideoResolution.FrameSize.Height;
                videoSource.NewFrame += new NewFrameEventHandler(video_NewFrame);
                videoSource.Start();
                stream?.Start();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            stream?.Stop();
            videoSource?.SignalToStop();
            Application.DoEvents();
            if (videoSource != null && videoSource.IsRunning && pictureBox1.Image != null)
            {
                pictureBox1.Image.Dispose();
            }
        }

        private void cmbVideoSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbVideoSource.SelectedIndex > -1)
            {
                cmbCameraMode.Items.Clear();
                videoSource = new VideoCaptureDevice(videoDevicesList[cmbVideoSource.SelectedIndex].MonikerString);
                var assa = videoSource.VideoCapabilities;
                videoSource.VideoResolution = videoSource.VideoCapabilities[0];
                for (int i = 0; i < videoSource.VideoCapabilities.Length; i++)
                {
                    cmbCameraMode.Items.Add($"{i} {videoSource.VideoCapabilities[i].FrameSize.Width}x{videoSource.VideoCapabilities[i].FrameSize.Height} {videoSource.VideoCapabilities[i].BitCount} {videoSource.VideoCapabilities[i].AverageFrameRate}");
                }
            }
        }
    }
}
