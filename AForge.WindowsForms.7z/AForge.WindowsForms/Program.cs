﻿using AForge.Video;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CameraController
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            /*
            if (args.Length == 0)
            {
                MessageBox.Show("Uruchom z parametrem katalogu gdzie masz obrazki");
                return;
            }
            else 
    */        
            if (args.Length==1)
                ImageLoader.ImageFolder = args[0];
            else if (args.Length==2)
            {
                ImageLoader.ImageFolder = args[0];
                ImageLoader.ImaguRI = args[1];
            }
            InitializeClass.Create();
            InitializeClass.StartingForm.Show();
            var form = new Form1();
            Application.Run(form);
        }
    }
}
