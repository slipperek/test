﻿using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;

namespace CameraController
{

   public class ImageLoader
    {
        private static string _imageFolder = @"D:\z_podloga";
        private static string _imageuRI = @"c";

        public static string ImageFolder { get => _imageFolder; set => _imageFolder = value; }
        public static string ImaguRI { get => _imageuRI; set => _imageuRI = value; }

        public static bool IsDirExists() => Directory.Exists(ImageFolder);
        public static IEnumerable<Bitmap> GetFromDir()
        {
            var d = new DirectoryInfo(ImageFolder);//Assuming Test is your Folder
            var Files = d.GetFiles("*.png"); //Getting Text files
            foreach (var file in Files)
            {
                Bitmap bitmap = new Bitmap(Path.Combine(ImageFolder, file.FullName));
                yield  return bitmap;
            }
        }
    }
}
