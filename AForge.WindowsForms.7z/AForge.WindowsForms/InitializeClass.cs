﻿namespace CameraController
{
    public static class InitializeClass
    {
        public static Form2 StartingForm;
        public static void  Create() { StartingForm = new Form2(); }
    }
}
